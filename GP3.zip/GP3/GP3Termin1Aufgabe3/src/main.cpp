#define F_CPU 16000000

#include <avr/io.h>
#include <util/delay.h>
#include <UART.h>
#include <I2C.h>

int main(void)
{
    // Initialisiert UART mit Baudrate 9600
    UART0_INIT(103);

    // Initialisiert die I2C-Schnittstelle
    I2CInit();

    uint8_t temp = i2c_find_address();
    UART0_send_ascii(temp);
}