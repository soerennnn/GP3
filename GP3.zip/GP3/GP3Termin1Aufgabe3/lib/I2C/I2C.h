/*******************************************************************************
 ***                                                                         ***
 *** filename:   I2C.h                                                       ***
 ***                                                                         ***
 *** project:    Grundpraktikum II                                           ***
 ***                                                                         ***
 *** created on: 2020-04-01                                                  ***
 ***                                                                         ***
 *** created by: Lukas Kroll                                                 ***
 ***             FH Dortmund                                                 ***
 ***             Labore fuer Informationstechnik                             ***
 ***             lukas.kroll@fh-dortmund.de                                  ***
 ***                                                                         ***
 ***                                                                         ***
 *** version:    1.0.0                                                       ***
 ***                                                                         ***
 *** updated on:                                                             ***
 ***                                                                         ***
 *** info:       I2C/I2C bibliothek Headerfile for use with 		         ***
 ***             Atmel Atmega 2560 only. Device Read/Write function          ***
 ***             specialized for use with Sensor MAX30105, ADS1115  	     ***
 ***             and SSD1306. Procedure may differ onother slave devices     ***
 ***                                                                         ***
 ******************************************************************************/

#ifndef I2C_H_
#define I2C_H_

#define MAX_I2C_ADDRESS 0x7F
#define FIRST_ADRESS 0x08
#define LAST_ADRESS 0x77
#define STATUS_SLA_TRANS_ACK_REC 0x18

#if defined(__AVR_ATmega2560__)
/**
 * @brief 	Initial configuration mehtod for I2C Interface configuration
 *
 * 			SCL depends on F_CPU, TWPS and TWBR:
 * 				SCL = CPU / ( 16 + 2(TWBR) * 4^TWPS )
 * 			TWSR - TWSR Status Register:
 * 				Bitrate Prescaler via  TWPS1, TWPS0
 * 				0,0 --> presclaer = 1
 * 				0,1 --> prescaler = 4
 * 				1,0 --> prescaler = 16
 * 				1,1 --> prescaler = 64
 * 			TWBR - I2C Bit Rate Register:
 * 				0x00 ... 0xFF
 * 			TWCR - I2C Control Register:
 * 				TWINT (R/W)	:TWI Interrupt FLag
 * 				TWEA  (R/W)	:TWI Enable Acknowledge Bit
 * 				TWSTA (R/W)	:TWI START Condition Bit
 * 				TWSTO (R/W)	:TWI STOP Condition Bit
 * 				TWWC  (R)	:TWI STOP Condition Bit
 * 				TWEN  (R/W)	:TWI enable Bit = 1 --> activates TWI interface
 * 				TWIE  (R/W)	:I2C Interrupt Enable
 */
void I2CInit(void);

uint8_t I2CStart(void); // Start der I2C Verbindung

void I2CStop(void); // Beenden der I2C Verbindung

uint8_t I2CWrite(uint8_t u8data); // Senden von Daten an den Slave (Byteweise)

uint8_t I2CReadACK(void); // Lesen des eingehenden Datenbytes mit Acknowledge

uint8_t I2CReadNACK(void); // Lesen des eingehenden Datenbytes ohne Acknowledge

uint8_t I2CGetStatus(void); // I2C Status Code auslesen

uint8_t i2c_find_address(void); // I2C Adresse finden

#endif /* __AVR_ATmega2560__ */
#endif /* I2C_H_ */
