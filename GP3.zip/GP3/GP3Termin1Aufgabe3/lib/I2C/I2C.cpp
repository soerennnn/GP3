/*******************************************************************************
 ***                                                                         ***
 *** filename:   I2C.cpp                                                    ***
 ***                                                                         ***
 *** project:    Grundpraktikum II                                           ***
 ***                                                                         ***
 *** created on: 2020-04-01                                                  ***
 ***                                                                         ***
 *** created by: Lukas Kroll                                                 ***
 ***             FH Dortmund                                                 ***
 ***             Labore fuer Informationstechnik                             ***
 ***             lukas.kroll@fh-dortmund.de                                  ***
 ***                                                                         ***
 ***                                                                         ***
 *** version:    1.0.0                                                       ***
 ***                                                                         ***
 *** updated on:                                                             ***
 ***                                                                         ***
 *** info:       I2C/I2C library for use with Atmel Atmega 2560 only      	 ***
 ***             Device Read function specialized for use with Sensor        ***
 ***             MAX30105 ADS1115 and SSD1306. Procedure may differ on 	     ***
 ***             other slave devices                                         ***
 ***                                                                         ***
 ******************************************************************************/

#include <avr/io.h>
#include "I2C.h"

void I2CInit(void)
{
	TWSR = 0x01;		// prescaler (in diesem Fall keiner --> 400kHz)
	TWBR = 0x02;		// Bit Raten Einstellung
	TWCR = (1 << TWEN); // I2C enable bit
}

uint8_t I2CStart(void)
{
	uint16_t time_out = 16000;
	TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN); // Interrupt Flag, Start Condition Bit, Enable Bit
	while (!(TWCR & (1 << TWINT)) && time_out)
		time_out--; // Warten bis Interrupt Flag auf Null geht
	return I2CGetStatus();
}

void I2CStop(void)
{
	TWCR = (1 << TWINT) | (1 << TWSTO) | (1 << TWEN); // Interrupt Flag, Stop Condition Bit, Enable Bit
}

uint8_t I2CWrite(uint8_t u8data)
{
	uint16_t time_out = 16000;
	TWDR = u8data; // Daten werden in das Date Register geschrieben, Daten aus dem TWDR werden auf SDA geshiftet
	TWCR = (1 << TWINT) | (1 << TWEN);
	while (!(TWCR & (1 << TWINT)) && time_out)
		time_out--; // Warten bis Interrupt Flag auf Null geht
	return I2CGetStatus();
}

uint8_t I2CReadACK(void) // Lesen von Daten mit Acknowledge Bit
{
	TWCR = (1 << TWINT) | (1 << TWEN) | (1 << TWEA);
	while ((TWCR & (1 << TWINT)) == 0)
		;
	return TWDR; // Ausgabe des eingelesenen Registers
}

uint8_t I2CReadNACK(void) // Lesen von Daten ohne Acknowledge Bit
{
	TWCR = (1 << TWINT) | (1 << TWEN);
	while ((TWCR & (1 << TWINT)) == 0)
		;
	return TWDR; // Ausgabe des eingelesenen Registrers
}

uint8_t I2CGetStatus(void) // Auslesen der ersten 5 Status Bits des Status Registers
{
	// mask status
	return TWSR & 0xF8;
}

uint8_t i2c_find_address()
{
	uint8_t address, status;

	// For Schleife durch die 112 Adresse. Erste Adresse 0x08. 0x00 - 0x07 belegt
	for (address = FIRST_ADRESS; address <= LAST_ADRESS; address++)
	{
		// Startbedingung senden
		I2CStart();

		// Adresse senden (schreibend -> LSB ist 0)
		status = I2CWrite((address << 1));

		// ACK erhalten, Gerät gefunden
		if (status == STATUS_SLA_TRANS_ACK_REC)
		{

			// Stop-Bedingung senden
			I2CStop();

			// Adresse zurückgeben
			return address;
		}

		// Stop-Bedingung senden
		I2CStop();
	}

	// Keine Adresse gefunden
	return 0x00;
}
