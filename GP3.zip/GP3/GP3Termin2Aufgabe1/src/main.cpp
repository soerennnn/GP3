#define F_CPU 16000000
#define SSD1306_ADDRESS 0x3C // I2C-Adresse des SSD1306
#define CO_CMD 0x80          // Controlbyte für Kommandos
#define CO_DATA 0x40         // Controlbyte für Displaydatne

#include <avr/io.h>
#include <util/delay.h>
#include <UART.h>
#include <I2C.h>

// uint8_t temp = i2c_find_address();
// UART0_send_ascii(temp);

// Array mit Konfigurationsparametern
uint8_t init_conf[] = {
    0x20,
    0x00,
    0xB0,
    0xC8,
    0x00,
    0x10,
    0x40,
    0x81,
    0x7F,
    0xA1,
    0xA6,
    0xA4,
    0xD3,
    0x00,
    0xDA,
    0x12,
    0xDB,
    0x20,
    0x8D,
    0x14,
    0xAF};

int main(void)
{
    uint8_t status;

    // Initialisiert UART mit Baudrate 9600
    UART0_INIT(103);

    // I2C initialisieren
    I2CInit();

    // Start-Bedingung senden und Display-Adresse schreiben mit Schreibbit
    status = I2CStart();
    UART0_send_ascii(status);
    UART0_send_str("\n");
    status = I2CWrite(SSD1306_ADDRESS << 1);
    UART0_send_ascii(status);
    UART0_send_str("\n");

    // Controlbyte für Commandbytes
    status = I2CWrite(CO_CMD);
    UART0_send_ascii(status);
    UART0_send_str("\n");

    // Jedes Byte im init_conf-Array senden
    for (uint8_t i = 0; i < sizeof(init_conf); i++)
    {
        // Konfigurationsbytes einzeln senden mit For Schleife
        status = I2CWrite(init_conf[i]);
        UART0_send_ascii(status);
        UART0_send_str("\n");
    }

    // Stop-Bedingung senden
    I2CStop();
}
