#define F_CPU 16000000

#define MAX_I2C_ADDRESS 0x7F



#include <avr/io.h>
#include <util/delay.h>
#include <UART.h>
#include <I2C.h>




int main(void) {
    uint8_t address, status;
    uint8_t found = 0;

    // Initialisiert UART mit Baudrate 9600 bei 16MHz Clock
    UART0_INIT(103);

    // Initialisiert die I2C-Schnittstelle
    I2CInit();

    

    for (address = 0x08; address <= 0x77; address++) {

        // Startbedingung senden
        I2CStart();

        // Adresse senden (schreibend -> LSB ist 0)
        status = I2CWrite((address << 1));

        // ACK erhalten, Gerät gefunden
        if (status == 0x18) {
            UART0_send_str("Gefundene I2C-Adresse: ");
            UART0_send_ascii(address);
            UART0_send_str("\n");
            found = 1;

            // Stop-Bedingung senden
            I2CStop();

            // Bei erster gefundenen Adresse Abbruch
            break;
        }

        //Stop-Bedingung senden
        I2CStop(); 
    }

    if (!found) {
        UART0_send_str("Keine I2C-Adresse gefunden\n");
    }

    while (1)
        ; // Endlos-Schleife, Programmende
}


