#define F_CPU 16000000

#include <avr/io.h>
#include <util/delay.h>
#include <UART.h>
#include <I2C.h>
#include "ssd1306.h"

int main(void)
{
    UART0_INIT(103);
    // SSD1306-Display-Objekt erzeugen
    ssd1306 display;

    // Initialisiere das Display
    display.init();

    
    while (1)
    {
    }
}
