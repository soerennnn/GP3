
#include "ssd1306.h"
#include "UART.h"
#include "I2C.h"

// Array mit den Initialisierungskonfiguration für das Display
// init_conf Mitglied der Klasse ssd1306. Statische Konfigurationsstruktur, die für alle Objekte gleich ist.
// Ändert sich nicht im Programm also static
uint8_t init_conf[] = {
    0x20, 0x00, 0xB0, 0xC8, 0x00, 0x10, 0x40, 0x81, 0x7F, 0xA1, 0xA6, 0xA4, 0xD3, 0x00, 0xDA, 0x12, 0xDB, 0x20, 0x8D, 0x14, 0xAF};

void ssd1306::init()
{
    uint8_t status;
    // Senden von Initialisierungskonfiguration
    // Übertragung starten und Adresse + R/W Bit
    status = I2CStart();
    UART0_send_ascii(status);
    UART0_send_str("\n");

    I2CWrite(I2C_ADDRESS << 1);
    UART0_send_ascii(I2C_ADDRESS);
    UART0_send_str("\n");

    // Controlbyte für Commands
    I2CWrite(CO_CMD);

    // Übertrage jedes Byte der Initialisierungskonfiguration vom Array
    for (uint8_t i = 0; i < sizeof(init_conf); i++)
    {
        status = I2CWrite(init_conf[i]);
        UART0_send_ascii(status);
        UART0_send_str("  -  ");
        UART0_send_ascii(i);
        UART0_send_str("  -  ");
        UART0_send_ascii(init_conf[i]);
        UART0_send_str("\n");
    }
    I2CStop();

    
}


