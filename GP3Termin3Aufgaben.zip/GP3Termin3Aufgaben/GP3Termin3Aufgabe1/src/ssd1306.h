
#define SSD1306_H

#include <avr/io.h>
#include <I2C.h>

// Definition der SSD1306-Klasse
class ssd1306
{
private:
    // Konstanten und I2C Adresse des Displays
    // Adresse des SSD1306-Displays
    const uint8_t I2C_ADDRESS = 0x3C;

    // Controlbyte für KCommands
    const uint8_t CO_CMD = 0x80;

    // Controlbyte für Displaydaten
    const uint8_t CO_DATA = 0x40;

public:
    // Framebuffer für Displayinhalt 
    // Framebuffer für jedes Objekt individuell, also nicht static
    uint8_t framebuffer[8][128];

    // Initialisierungsparameter fr das Display
    uint8_t init_conf[21];

    // Initialisiert das Display
    void init();

    // Aktualisiert den Displayinhalt mit dem Framebuffer
    void update();

    // Löscht den Framebuffer, alles auf 0x00
    void clear();
};

