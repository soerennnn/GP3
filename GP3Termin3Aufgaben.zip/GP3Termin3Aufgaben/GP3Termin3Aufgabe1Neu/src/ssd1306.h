#include <avr/io.h>
#include <I2C.h>

// Definition der SSD1306-Klasse
class ssd1306
{
private:
    // Konstanten und I2C Adresse des Displays
    // Adresse des SSD1306-Displays
    const uint8_t I2C_ADDRESS = 0x3C;

    // Controlbyte für KCommands
    const uint8_t CO_CMD = 0x80;

    // Controlbyte für Displaydaten
    const uint8_t CO_DATA = 0x40;

public:
    // Framebuffer für Displayinhalt
    // Framebuffer für jedes Objekt individuell, also nicht static
    uint8_t framebuffer[8][128];

    // Initialisierungsparameter für das Display
    uint8_t init_conf[21]{
        0x20, 0x00, 0xB0, 0xC8, 0x00, 0x10, 0x40, 0x81, 0x7F, 0xA1, 0xA6, 0xA4, 0xD3, 0x00, 0xDA, 0x12, 0xDB, 0x20, 0x8D, 0x14, 0xAF};

    // Initialisiert das Display
    void init();

    // Alles im Framebuffer auf 0x00
    void clear();

    // Auf Page 0 Segment 0 stellen und Framebuffer auf Display übertragen
    void update();
};