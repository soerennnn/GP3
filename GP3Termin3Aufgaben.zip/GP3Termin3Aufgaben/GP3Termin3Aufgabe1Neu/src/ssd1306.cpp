
#include <ssd1306.h>
#include <UART.h>
#include <I2C.h>

// init_conf Mitglied der Klasse ssd1306. Statische Konfigurationsstruktur, die für alle Objekte gleich ist.

// Funktion zur Initalisierung
void ssd1306::init()
{
    uint8_t status;

    // Senden von Initialisierungskonfiguration
    // Übertragung starten und Adresse + R/W Bit
    status = I2CStart();
    UART0_send_str("Start Status: ");
    UART0_send_ascii(status);
    UART0_send_str("\n");

    UART0_send_str("Adresse: ");
    UART0_send_ascii(I2C_ADDRESS);
    UART0_send_str("\n");

    status = I2CWrite(I2C_ADDRESS << 1);
    UART0_send_str("Adresse + W Bite Status: ");
    UART0_send_ascii(status);
    UART0_send_str("\n");
    UART0_send_str("Adresse nach Shift: ");
    UART0_send_ascii(I2C_ADDRESS << 1);
    UART0_send_str("\n");

    // Controlbyte für Commands
    I2CWrite(CO_CMD);

    // Übertrage jedes Byte der Initialisierungskonfiguration vom Array
    for (uint8_t i = 0; i < sizeof(init_conf); i++)
    {

        UART0_send_str("Status Übertragung: ");
        status = I2CWrite(init_conf[i]);
        UART0_send_ascii(status);
        UART0_send_str("  -  ");
        UART0_send_str("Array Index: ");
        UART0_send_ascii(i);
        UART0_send_str("  -  ");
        UART0_send_str("Array Inhalt: ");
        UART0_send_ascii(init_conf[i]);
        UART0_send_str("\n");
    }
    I2CStop();
    clear();
    update();
}

// Setzt jedes Byte im Framebuffer auf 0x00
void ssd1306::clear()
{
    UART0_send_str("Funktion clear() aufgerufen");
    UART0_send_str("\n");
    for (uint8_t page = 0; page < 8; page++)
    {
        for (uint8_t segment = 0; segment < 128; segment++)
        {
            UART0_send_ascii(page);
            UART0_send_str(" - ");
            UART0_send_ascii(segment);
            UART0_send_str(" - ");
            framebuffer[page][segment] = 0x00;
            UART0_send_str("Array Inhalt: ");
            UART0_send_ascii(framebuffer[page][segment]);
            UART0_send_str("\n");
        }
    }
}

void ssd1306::update()
{
    uint8_t statusUpdate;
    // Setze Startposition auf Page 0, Segment 0
    UART0_send_str("\n");

    statusUpdate = I2CStart();
    UART0_send_str("Update Funktion");
    UART0_send_str("Status Start: ");
    UART0_send_ascii(statusUpdate);
    UART0_send_str("\n");

    statusUpdate = I2CWrite(I2C_ADDRESS << 1);
    UART0_send_str("Status Adresse + Schreibbit: ");
    UART0_send_ascii(statusUpdate);
    UART0_send_str("\n");

    statusUpdate = I2CWrite(CO_CMD);
    UART0_send_ascii(statusUpdate);
    UART0_send_str("\n");

    statusUpdate = I2CWrite(0xB0);
    UART0_send_ascii(statusUpdate);
    UART0_send_str("\n");

    statusUpdate = I2CWrite(0x00);
    UART0_send_ascii(statusUpdate);
    UART0_send_str("\n");

    statusUpdate = I2CWrite(0x10);
    UART0_send_ascii(statusUpdate);
    UART0_send_str("\n");

    statusUpdate = I2CWrite(0x40);
    UART0_send_ascii(statusUpdate);
    UART0_send_str("\n");
    I2CStop();

    // Übertrage den Framebuffer-Seiteninhalt an das Display
    for (uint8_t page = 0; page < 8; page++)
    {
        statusUpdate = I2CStart();
        UART0_send_str("Status Start Page: ");
        UART0_send_ascii(statusUpdate);
        UART0_send_str(" - ");
        UART0_send_ascii(page);
        UART0_send_str("\n");
        // Display Adresse mit Schreibbit
        I2CWrite(I2C_ADDRESS << 1);

        // Controlbyte für Displaydaten
        I2CWrite(CO_DATA);

        for (uint8_t segment = 0; segment < 128; segment++)
        {
            I2CWrite(framebuffer[page][segment]);
        }
        I2CStop();
    }
}